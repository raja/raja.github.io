package main

import (
	"bytes"
	"encoding/json"
	"encoding/xml"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"regexp"
	"strings"
	"time"

	"github.com/algolia/algoliasearch-client-go/algoliasearch"
	"github.com/yhat/scrape"
	"golang.org/x/net/html"
	"golang.org/x/net/html/atom"
)

//URLSet containts the complete array of all URLs
type URLSet struct {
	XMLName xml.Name `xml:"urlset"`
	URLs    []URL    `xml:"url"`
}

//URL containts location and last updated, as well as content, etc
type URL struct {
	XMLName xml.Name `xml:"url"`
	//Type         string
	Location     string    `xml:"loc"`
	LastModified time.Time `xml:"lastmod"`
}

type searchObject struct {
	Title         string   `json:"title"`
	Body          string   `json:"body"`
	Categories    []string `json:"categories"`
	Location      string   `json:"location"`
	PublishedAt   int64    `json:"publishedAt"`
	PublishedYear int      `json:"publishedYear"`
	TotalWords    int      `json:"totalWords"`
	TotalImages   int      `json:"totalImages"`
	TotalLinks    int      `json:"totalLinks"`
}

// TotalWords returns an int of the total number of words in a given content.
func TotalWords(s string) int {
	return len(strings.Fields(s))
}

// WordCount takes content and returns a map of words and count of each word.
func WordCount(s string) map[string]int {
	m := make(map[string]int)
	for _, f := range strings.Fields(s) {
		m[f]++
	}

	return m
}

func imgCount(s string) int {
	re := regexp.MustCompile("<img")
	matches := re.FindAllStringIndex(s, -1)
	return len(matches)
}

//Doesn't take into account that many links are just wrapped img tags
func linkCount(s string) int {
	re := regexp.MustCompile("<a")
	matches := re.FindAllStringIndex(s, -1)
	return len(matches)
}

func getHTTP(url string) []byte {
	res, err := http.Get(url)
	if err != nil {
		log.Fatal(err)
	}
	defer res.Body.Close()

	payload, err := ioutil.ReadAll(res.Body)
	if err != nil {
		log.Fatal(err)
	}
	return payload
}

func parsePost(url URL) searchObject {
	body := bytes.NewReader(getHTTP(url.Location))
	root, _ := html.Parse(body)

	postMatcher := func(n *html.Node) bool {
		// must check for nil values
		if n.DataAtom == atom.Div && scrape.Attr(n, "class") == "col-lg-6 post" {
			return true
		}
		return false
	}

	titlelMatcher := func(n *html.Node) bool {
		if n.DataAtom == atom.H1 && n.Parent.DataAtom == atom.Div && scrape.Attr(n.Parent, "class") == "col-lg-6 post" {
			return true
		}
		return false
	}

	categoryMatcher := func(n *html.Node) bool {
		// must check for nil values
		if n.DataAtom == atom.P && scrape.Attr(n, "align") == "right" {
			return true
		}
		return false
	}

	socialMatcher := func(n *html.Node) bool {
		if n.DataAtom == atom.Div && n.Parent.DataAtom == atom.Div && scrape.Attr(n.Parent, "class") == "col-lg-6 post" {
			return true
		}
		return false
	}

	footnoteMatcher := func(n *html.Node) bool {
		// must check for nil values
		if n.DataAtom == atom.Div && scrape.Attr(n, "style") == "text-align: justify; padding" {
			return true //n.FirstChild.DataAtom == atom.Hr
		}
		return false
	}

	parseCategories := func(parent *html.Node) []string {
		links := scrape.FindAll(parent, scrape.ByTag(atom.A))
		var categories []string
		for _, link := range links {
			categories = append(categories, scrape.Text(link))
		}
		return categories
	}
	// Search for the title
	title, _ := scrape.Find(root, scrape.ByTag(atom.Title))
	post, _ := scrape.Find(root, postMatcher)
	postContent := new(bytes.Buffer)
	category, _ := scrape.Find(post, categoryMatcher)
	social, _ := scrape.Find(post, socialMatcher)
	titleTag, _ := scrape.Find(post, titlelMatcher)
	footnote, _ := scrape.Find(post, footnoteMatcher)

	post.RemoveChild(titleTag)
	post.RemoveChild(category)
	post.RemoveChild(footnote)
	post.RemoveChild(social)

	html.Render(postContent, post)
	postHTML := postContent.String()
	re := regexp.MustCompile("(?m)^\\s*$[\r\n]*")
	postHTML = strings.Trim(re.ReplaceAllString(postHTML, ""), "\r\n")

	/*fmt.Println("Post text is ", scrape.Text(post))
	fmt.Printf("Link %s, date: %s\n", url.Location, url.LastModified.Format("2006-01-02"))
	fmt.Println("Title is: ", scrape.Text(title))
	fmt.Println("Total words: ", TotalWords(scrape.Text(post)))
	fmt.Println("Total links: ", linkCount(postHTML))
	fmt.Println("Total images: ", imgCount(postHTML))*/

	obj := searchObject{}
	obj.Title = scrape.Text(title)
	obj.Body = scrape.Text(post)
	obj.Location = url.Location
	obj.PublishedAt = url.LastModified.Unix()
	obj.PublishedYear = url.LastModified.Year()
	obj.TotalWords = TotalWords(obj.Body)
	obj.TotalLinks = linkCount(postHTML)
	obj.TotalImages = imgCount(postHTML)
	obj.Categories = parseCategories(category)
	return obj
}

func main() {
	const sitemapURL string = "http://tomtunguz.com/sitemap.xml"
	client := algoliasearch.NewClient("XXX", "XXX")
	index := client.InitIndex("tt_blog")

	fmt.Println("Let's parse out Tomas' Blog at ", sitemapURL)
	sitemap := getHTTP(sitemapURL)

	var urlset URLSet
	err := xml.Unmarshal(sitemap, &urlset)
	if err != nil {
		log.Fatal(err)
	}
	fmt.Println("Number of URLs in sitemap:", len(urlset.URLs))

	//Regex for urls that aren't single page posts
	regex := regexp.
		MustCompile(
			`http:\/\/www.tomtunguz\.com\/(\z|categories\/+|tags\/+|feed\/+|post\/+)`)

	len := len(urlset.URLs) //10
	var searchContent []searchObject
	for i := 0; i < len; i++ {
		url := urlset.URLs[i]
		if !regex.MatchString(url.Location) && url.LastModified.Year() != 1 {
			fmt.Println(url.Location)
			obj := parsePost(url)
			searchContent = append(searchContent, obj)
		}
	}
	var objects []algoliasearch.Object
	res, _ := json.Marshal(searchContent)
	if err := json.Unmarshal(res, &objects); err != nil {
		return
	}
	params := algoliasearch.Map{
	// Set your search parameters here
	}
	index.DeleteByQuery("*", params)
	_, err = index.AddObjects(objects)
	if err != nil {
		log.Fatal(err)
	}
}
