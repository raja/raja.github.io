import React, { Component } from 'react';
import {InstantSearch, Hits, SearchBox, Highlight, RefinementList, CurrentRefinements, ClearAll, Pagination, Snippet} from 'react-instantsearch/dom';
import './App.css';

function Post({hit}) {
  return (
    <div>
      <p><h3><a href={hit.location} target="_blank"><Highlight attributeName="title" hit={hit}/></a></h3>
      <small>Published on {hit.publishedAt} </small></p>
      <Snippet attributeName="body" hit={hit} />...
      <p><small>
        Wordcount: {hit.totalWords}
      </small></p>
    </div>
  )
}

function Search() {
  return (
    <div className="search">
      <strong>Categories</strong>
      <RefinementList attributeName="categories" />
      <br />
      <strong>Year</strong>
      <RefinementList attributeName="publishedYear" />
      <br />
      <ClearAll/>
    </div>
  );
}


class App extends Component {

  render() {
    return (
      <InstantSearch appId="FRPSH9PW83" apiKey="f23c20c2934d98f9bad038a258efdc59" indexName="tt_blog">
        <div className="container">
          <div className="col-xs-12" style={{color: "rgb(240, 36, 37)", padding: "1em 0em 2em 0em"}}>
            <h1>🚀 TT Search</h1>
          </div>
          <div className="col-xs-4">
            <Search/>
          </div>
          <div className="col-xs-8">
            <header className="App-header">
              <SearchBox />
            </header>
            <CurrentRefinements />
            <Hits hitComponent={Post}/>
            <Pagination />
          </div>
        </div>
      </InstantSearch>
    );
  }
}

export default App
